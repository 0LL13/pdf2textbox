The pdf2textbox converter aims at converting PDF that comes                        in up to three columns and a header into text without loosing                        too much information.                        Allows command line parameter -s (--slice) to indicate that                        only part of the PDF document is of interest. Start and end                        page will then either retreived from the document's name                        using either '_' or '|' as delimiters or - if start and end                        page cannot be found - user input is requested.


